<?php 
/**
 * The template for displaying all pages.
 * Template name:Projects 
 * This is the template that displays the contact us page
 * 
 */ 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
global $post;
include 'templates/projects/archive-projects.php';
?>
