<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
define('WP_USE_THEMES', false);
require_once(get_home_path().'/wp-load.php');  
?> 
 
<div class="cap " id="model">   
	<div class="wrap"> 
 		<div class="box-wrap">
		settings
		</div>
	</div> 
</div>
